from fastapi import FastAPI, Form, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from transformers import pipeline

app = FastAPI()

# Mount static files and templates
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# Initialize Hugging Face zero-shot classification pipeline
symptom_classifier = pipeline("zero-shot-classification", model="facebook/bart-large-mnli")

# Define symptom categories and corresponding health tips
symptom_categories = {
    "default": "Consider consulting a doctor for a proper diagnosis, especially if symptoms persist or worsen.",
    "headache": "Drink plenty of water, rest in a quiet and dark room, and consider over-the-counter pain relievers if needed. If the headache persists, consult a doctor.",
    "back pain": "Ensure you maintain good posture, perform gentle stretches, and apply a heat or cold pack to the affected area. If pain continues, a professional evaluation may be necessary.",
    "fever": "Stay hydrated, rest, and take antipyretic medication like paracetamol. If the fever lasts for more than a few days, seek medical attention.",
    "cold": "Drink warm fluids, rest, and take decongestants or antihistamines if needed. If the cold symptoms persist or worsen, consult a healthcare provider.",
    "nausea": "Rest, drink clear fluids like ginger tea, and avoid greasy or spicy foods. If nausea continues, consider visiting a doctor.",
    "stomach ache": "Rest and avoid heavy meals. Try drinking herbal teas like peppermint or chamomile. If pain is severe or persistent, see a doctor.",
    "fatigue": "Ensure you're getting adequate rest, stay hydrated, and avoid caffeine late in the day. If fatigue continues despite rest, consider seeing a healthcare professional.",
    "sore throat": "Gargle with warm salt water, drink warm tea with honey, and rest your voice. If the sore throat lasts more than a few days, consult a doctor.",
    "cough": "Stay hydrated, use a humidifier, and take cough syrups if needed. If the cough persists or worsens, see a healthcare provider.",
    "dizziness": "Sit or lie down to prevent falls, stay hydrated, and avoid sudden movements. If dizziness continues or is accompanied by other symptoms, seek medical attention.",
    "chest pain": "If the chest pain is severe or accompanied by shortness of breath, seek emergency medical attention immediately.",
    "rash": "Avoid scratching, keep the area clean, and apply soothing lotions like calamine. If the rash is widespread or accompanied by fever, consult a doctor.",
    "shortness of breath": "Stay calm and try to breathe slowly. If the shortness of breath worsens or is severe, seek immediate medical help.",
    "swelling": "Elevate the swollen area, apply a cold compress, and rest. If swelling persists or is accompanied by pain, consult a healthcare provider.",
    "joint pain": "Rest the affected joint, apply ice or heat as needed, and consider over-the-counter pain relief. If the pain continues, seek professional advice.",
    "diarrhea": "Stay hydrated with clear fluids and avoid heavy foods. If diarrhea lasts for more than a few days, or is severe, see a doctor.",
    "constipation": "Increase fiber intake, drink plenty of water, and try gentle exercises. If constipation continues, consult a healthcare provider.",
    "insomnia": "Try to establish a regular sleep routine, limit caffeine and screen time before bed, and create a relaxing environment. If insomnia persists, seek professional help.",
    "anxiety": "Practice relaxation techniques, like deep breathing or meditation. If anxiety is overwhelming or persistent, consider speaking to a therapist.",
    "depression": "Try to engage in activities you enjoy, stay connected with loved ones, and seek support from a mental health professional if symptoms persist.",
    "muscle cramps": "Stretch the affected muscle gently, apply heat or cold, and stay hydrated. If cramps persist, consider seeing a healthcare provider.",
    "sweating": "Wear loose clothing and stay in a cool environment. If excessive sweating continues, consult a doctor.",
    "itching": "Avoid scratching, moisturize the skin, and use anti-itch creams if needed. If itching persists or worsens, consult a healthcare provider.",
    "bloody nose": "Pinch the nostrils together and lean forward slightly. If bleeding persists or happens frequently, consult a doctor.",
    "hiccups": "Try drinking water slowly, holding your breath, or swallowing a teaspoon of sugar. If hiccups persist for more than 48 hours, see a healthcare provider.",
    "weight loss": "Ensure you're eating a balanced diet and staying hydrated. If the weight loss is sudden or unexplained, consult a doctor.",
    "weight gain": "Monitor your diet and exercise regularly. If the weight gain is sudden or unexplained, consult a healthcare provider.",
    "blurred vision": "Rest your eyes and reduce screen time. If blurred vision persists or is accompanied by pain, consult an eye specialist.",
    "eye strain": "Take regular breaks from screens, adjust lighting, and ensure you're wearing proper glasses or contacts. If the strain continues, seek professional advice.",
    "ear pain": "Avoid inserting objects into the ear, and try using a warm compress. If the pain persists, see a healthcare provider.",
    "toothache": "Rinse with warm salt water, apply a cold compress to the outside of your cheek, and take over-the-counter pain relievers. If the pain continues, consult a dentist.",
    "bad breath": "Ensure you're brushing and flossing regularly, stay hydrated, and avoid strong-smelling foods. If bad breath persists, consult a dentist.",
    "dry mouth": "Drink plenty of water and consider using saliva substitutes. If the dryness continues, consult a healthcare provider.",
    "numbness": "Avoid pressure on the affected area and perform gentle stretches. If numbness persists or spreads, seek medical attention.",
    "cold hands and feet": "Try warming the area with blankets or warm water. If the coldness persists or is accompanied by other symptoms, consult a healthcare provider.",
    "heart palpitations": "Sit or lie down and try to relax. If the palpitations are accompanied by chest pain or shortness of breath, seek emergency help.",
    "high blood pressure": "Monitor your blood pressure regularly, reduce salt intake, and exercise. If blood pressure remains high, consult a healthcare provider.",
    "low blood pressure": "Increase fluid intake, eat small frequent meals, and avoid standing up too quickly. If symptoms persist, seek medical advice.",
    "allergic reaction": "Avoid the allergen, take antihistamines, and apply hydrocortisone cream to the skin. If the reaction is severe, seek immediate medical help.",
    "shivering": "Wear warm clothing and drink hot liquids. If shivering persists or is severe, consult a doctor.",
    "night sweats": "Wear lightweight clothing and use breathable bedding. If night sweats persist, consult a healthcare provider.",
    "vomiting": "Stay hydrated with clear liquids, avoid solid foods until the vomiting subsides. If vomiting is persistent, consult a doctor.",
    "abdominal bloating": "Try eating smaller meals, avoid gas-producing foods, and consider taking antacids. If bloating persists, see a healthcare provider.",
    "heartburn": "Avoid spicy foods, drink water, and try antacids. If heartburn continues, consult a doctor.",
    "gastrointestinal bleeding": "If you notice blood in your stool or vomit, seek medical help immediately.",
    "hives": "Avoid scratching, take antihistamines, and apply soothing creams. If hives persist or worsen, consult a healthcare provider.",
    "burns": "Cool the burn under running cold water, apply a sterile dressing, and avoid breaking blisters. If the burn is severe, seek medical attention.",
    "sunburn": "Apply aloe vera or over-the-counter creams, stay hydrated, and avoid further sun exposure. If symptoms worsen, consult a doctor.",
    "hair loss": "Maintain a healthy diet, avoid excessive heat or chemicals on your hair, and consult a dermatologist if the hair loss persists.",
    "tinnitus": "Avoid loud noises, manage stress, and consult an audiologist if tinnitus continues or worsens.",
    "ringing in the ears": "Avoid loud noises, limit caffeine, and manage stress. If the ringing persists, consult a healthcare provider.",
    "chronic cough": "Stay hydrated, use a humidifier, and take cough syrups. If the cough persists for more than a few weeks, consult a healthcare provider.",
    "swollen lymph nodes": "Rest, stay hydrated, and apply a warm compress. If the swelling persists, see a doctor.",
    "muscle weakness": "Try to get sufficient rest, eat nutritious foods, and avoid overexertion. If weakness persists, consult a healthcare provider.",
}


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    """Render the homepage."""
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/get_tips", response_class=HTMLResponse)
async def get_tips(request: Request, symptom: str = Form(...)):
    """Analyze symptoms and return health tips."""
    
    # Define possible symptom categories for zero-shot classification
    categories = list(symptom_categories.keys())
    
    # Use the model to predict the most likely category
    result = symptom_classifier(symptom, candidate_labels=categories)
    
    # Get the best match (highest confidence)
    best_match = result["labels"][0]  # First label is the highest confidence label
    
    # Fetch the appropriate health tips from the predefined dictionary
    tips = symptom_categories.get(best_match, symptom_categories["default"])
    
    # Return the response with health tips
    return templates.TemplateResponse("index.html", {"request": request, "symptom": symptom, "tips": tips})
